//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Server.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_SERVERTYPE                  129
#define IDD_DLG_CONNECT                 130
#define IDR_MAINFRAME1                  132
#define IDD_DLG_HELP                    132
#define IDC_BTN_SEARCH                  1000
#define IDC_BTN_ADD                     1001
#define IDC_BTN_DEL                     1002
#define IDC_BTN_MODIFY                  1003
#define IDC_BTN_SUBMIT                  1004
#define IDC_BTN_CANCEL                  1005
#define IDC_LIST1                       1006
#define IDM_START                       32771
#define IDM_STOP                        32772
#define IDM_OPERATE                     32774

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32775
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
